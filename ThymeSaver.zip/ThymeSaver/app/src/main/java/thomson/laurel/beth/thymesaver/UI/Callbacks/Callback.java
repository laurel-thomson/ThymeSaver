package thomson.laurel.beth.thymesaver.UI.Callbacks;

public interface Callback {
    void onSuccess();
    void onError(String err);
}