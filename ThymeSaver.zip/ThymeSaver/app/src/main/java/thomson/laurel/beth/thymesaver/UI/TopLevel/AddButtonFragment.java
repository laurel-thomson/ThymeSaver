package thomson.laurel.beth.thymesaver.UI.TopLevel;

import android.support.v4.app.Fragment;

public abstract class AddButtonFragment extends Fragment {
    public abstract void onFABClicked();
}
